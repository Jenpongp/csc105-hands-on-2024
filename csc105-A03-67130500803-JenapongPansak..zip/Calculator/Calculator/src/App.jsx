import React, { useState } from "react";
import Wrapper from "./components/Wrapper";
import Screen from "./components/Screen";
import ButtonBox from "./components/ButtonBox";
import Button from "./components/Button";

const btnValues = [
    ["ClearAll", "/", "=", "+", "-", "*"],
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
];

const App = () => {
    const [calc, setCalc] = useState({ sign: "", num: "", res: "0" });

    const numClickHandler = (e) => {
        const value = e.target.innerHTML;

            if (calc.num === "0") {
                setCalc({ ...calc, num: value });
            } else {
                setCalc({ ...calc, num: calc.num + value });
            }

    };

    const signClickHandler = (e) => {
        const value = e.target.innerHTML;

        if (calc.num !== "") {
            setCalc({ sign: value, res: calc.num, num: "" });
        } else if (calc.res !== "0") {
            setCalc({ sign: value, res: calc.res, num: "" });
        }
    };

    const equalsClickHandler = () => {
        if (calc.sign && calc.num) {
            const a = Number(calc.res);
            const b = Number(calc.num);
            let result = "0";

            switch (calc.sign) {
                case "+":
                    result = a + b;
                    break;
                case "-":
                    result = a - b;
                    break;
                case "*":
                    result = a * b;
                    break;
                case "/":
                    result = b === 0 ? "Error" : a / b;
                    break;
                default:
                    return;
            }

            setCalc({ sign: "", num: "", res: result });
        }
    };

    const resetClickHandler = () => {
        setCalc({ sign: "", num: "", res: "0" });
    };

    return (
        <Wrapper>
            <Screen value={calc.num || calc.res} />
            <ButtonBox>
                {btnValues.flat().map((btn, i) => (
                    <Button
                        key={i}
                        className={btn === "=" ? "equals" : ""}
                        value={btn}
                        onClick={
                            btn === "ClearAll"
                                ? resetClickHandler
                                : btn === "="
                                    ? equalsClickHandler
                                    : ["/", "+", "-", "*"].includes(btn)
                                        ? signClickHandler
                                        : numClickHandler
                        }
                    />
                ))}
            </ButtonBox>
        </Wrapper>
    );
};

export default App;
