import React, { useState } from "react";

const ShoppingList = () => {
    const [items, setItems] = useState([]);
    const [newItem, setNewItem] = useState("");
    const [editingIndex, setEditingIndex] = useState(null);
    const [editingValue, setEditingValue] = useState("");

    const addItem = () => {
        if (newItem) {
            setItems([...items, newItem]);
            setNewItem("");
        }
    };

    const removeItem = (index) => {
        const newItems = [...items];
        newItems.splice(index, 1);
        setItems(newItems);
    };

    const startEditing = (index) => {
        setEditingIndex(index);
        setEditingValue(items[index]);
    };

    const saveEdit = () => {
        const newItems = [...items];
        newItems[editingIndex] = editingValue;
        setItems(newItems);
        setEditingIndex(null);
        setEditingValue("");
    };

    return (
        <div style={{ maxWidth: "400px", margin: "20px auto", textAlign: "center" }}>
            <h2>Shopping List</h2>

            <input
                type="text"
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
                placeholder="Add item"
            />
            <button onClick={addItem}>Add</button>

            <ul>
                {items.map((item, index) => (
                    <li key={index}>
                        {editingIndex === index ? (
                            <>
                                <input
                                    type="text"
                                    value={editingValue}
                                    onChange={(e) => setEditingValue(e.target.value)}
                                />
                                <button onClick={saveEdit}>Save</button>
                            </>
                        ) : (
                            <>
                                {item}
                                <button onClick={() => startEditing(index)}>Edit</button>
                                <button onClick={() => removeItem(index)}>Remove</button>
                            </>
                        )}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ShoppingList;