import React from "react";
import ShoppingList from "./ShoppingList";

function App() {
    return (
        <div>
            <ShoppingList/>
        </div>
    );
}

export default App;
